## Instructions

1. sudo apt-get install python-pip
2. sudo apt-get install python3-pip
3. python2 -m pip install virtualenv
4. cd /home/
5. virtualenv -p python2 venv
6. source venv/bin/activate
7. git clone https://github.com/Tsuyoshi-Hashimoto/DeepNeuralnets--Alzheimer
8. pip install -r DeepNeuralnets--Alzheimer/requirements.txt

This will install all the packages for you.
