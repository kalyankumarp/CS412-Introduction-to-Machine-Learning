![functioning](https://github.com/Tsuyoshi-Hashimoto/DeepNeuralnets--Alzheimer/blob/master/images/code-1.jpg)
![architecture](https://github.com/Tsuyoshi-Hashimoto/DeepNeuralnets--Alzheimer/blob/master/images/code-2.jpg)
