# Not Maintained

Since this repository is actually getting some stars on Github I wanted to post a small update. 

This repository was not meant as an example or guide of anysort therefore it is totally uncommented and poorly written. Currently it is unmaintained I hope I'm able to update this repository in the future and write documentation for it.

Dataset is available here: https://drive.google.com/file/d/0B5zQ7kc5shlgRG9laXMxcnlyMk0/view?usp=sharing

Project paper written for the university course is available here: https://github.com/regnerus/keras-alzheimers-3d-conv/files/2111208/main.pdf
