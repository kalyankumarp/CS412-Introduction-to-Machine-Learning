This folder contains all the images that I found useful in the creation of this project.
